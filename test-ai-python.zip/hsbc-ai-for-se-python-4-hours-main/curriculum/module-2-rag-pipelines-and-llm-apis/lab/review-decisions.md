# My review decisions

You are the human reviewer. For each question you ran with `bash scripts/demo.sh`, record what you decided and why.
One short line per cell is enough. Save the file (Ctrl+S) when you are done.

| # | Question | Did you approve (y) or reject (n)? | Why (one line) | Which source chunk did you check it against? |
|---|---|---|---|---|
| 1 | What time is the cutoff for same-day settlement? | y | Approve only if the answer gives 2:00 PM local market time and adds no unsupported time zone. | trade_settlement_policy.txt, chunk 1 |
| 2 | Can a failed payment be retried with the same payment id? | y | A failed payment is final and must be re-submitted as a new payment. | payment_rail_operations_handbook.txt, chunk 1 |
| 3 | What is the high-value limit for stuck payments? | n | The handbook names a high-value limit but gives no number, so an invented value or unsupported answer must be rejected. | payment_rail_operations_handbook.txt, chunk 1 |

Which of the three was hardest to judge, and why? (one line): The third is hardest because the document references a high-value limit but does not state its value, requiring an answer to explicitly say it does not know.
