from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class PaymentState(str, Enum):
    submitted = "submitted"
    settled = "settled"
    failed = "failed"


class PaymentEvent(BaseModel):
    event_id: str = Field(min_length=1, max_length=64)
    payment_id: str = Field(min_length=1, max_length=64)
    state: PaymentState
    occurred_at: datetime

    @field_validator("event_id", "payment_id")
    @classmethod
    def validate_non_empty_id(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("id must not be empty or whitespace")
        return value

    @field_validator("occurred_at")
    @classmethod
    def validate_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("occurred_at must be timezone-aware")
        return value


class PaymentStatus(BaseModel):
    payment_id: str = Field(min_length=1, max_length=64)
    state: PaymentState
    updated_at: datetime

    @field_validator("payment_id")
    @classmethod
    def validate_non_empty_id(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("id must not be empty or whitespace")
        return value

    @field_validator("updated_at")
    @classmethod
    def validate_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("updated_at must be timezone-aware")
        return value


class ErrorResponse(BaseModel):
    code: Optional[str] = None
    message: Optional[str] = None
