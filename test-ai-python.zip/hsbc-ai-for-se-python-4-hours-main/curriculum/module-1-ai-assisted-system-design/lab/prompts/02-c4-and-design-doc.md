![General Assembly](/curriculum/assets/ga-logo-black-background.png)

# Prompt 2: C4 diagram and design document

Use the attached PRD, the design we chose in the previous step, and the lab assumptions if applicable.
Do not introduce requirements, services, or targets that are not present in those sources.

Produce exactly these two artifacts:

1. **C4 container outline**
   - Use a people/container-style outline only; do not include classes or deployment nodes.
   - Include: the people or roles that use the system, this one Python service, its database, and external systems.
   - Label every arrow with the protocol or interaction and the data flowing across it.
   - Show the payment rail sending state-change notifications and internal callers retrieving status.
   - Mark assumptions that are not stated in the PRD.

2. **One-page design document**
   Use only these headings:
   - Context
   - Decisions
   - Data model
   - API summary
   - Risks
   - Open questions

   In **Decisions**, give each decision a title, the alternative rejected and why, and the selected option.
   In **Data model**, define only the fields needed for the chosen design and identify primary and idempotency keys.
   In **API summary**, summarize the notification and retrieval interactions using the contract already selected for the lab.
   In **Risks**, distinguish PRD gaps and design risks, and name the mitigation or owner needed for each.
   In **Open questions**, list unresolved product decisions; do not silently convert them into facts.

Keep the design scoped to ONE service. Put components owned by another team or system in external boxes.
Keep the answer concise enough to fit on one page and include no code or pseudo-code.
