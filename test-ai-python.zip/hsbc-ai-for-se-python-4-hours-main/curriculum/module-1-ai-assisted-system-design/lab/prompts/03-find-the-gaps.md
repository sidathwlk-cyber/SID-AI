![General Assembly](/curriculum/assets/ga-logo-black-background.png)

# Prompt 3: find the most important gaps in the PRD

Act as a skeptical senior engineer reviewing the attached PRD before sprint planning.
Use only the PRD and the lab assumptions as supplied; do not invent unstated requirements or targets.

Identify the FIVE gaps or ambiguities most likely to cause rework. Rank them from most to least important.
For each gap, provide exactly one line containing:
- the PRD requirement or section affected
- the question you would ask the product owner
- a reasonable default to use until an answer is provided

Cover gaps across the whole system, especially: identifiers, allowed state transitions, duplicate and out-of-order notifications,
who may call or send what, timestamp semantics, performance and availability targets, failure handling, and security.
Do not repeat assumptions already resolved by the lab assumptions as gaps, and do not write code.

After the five lines, add one final line beginning `Highest risk:` that names the single riskiest gap and explains why it matters for a bank.
Keep the response short and evidence-based.
