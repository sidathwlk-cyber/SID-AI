![General Assembly](/curriculum/assets/ga-logo-black-background.png)

# Prompt 1: architecture trade-offs

Act as a skeptical senior engineer reviewing a small Python microservice for a bank.
Use only the attached PRD (`prd/payment-status-prd.md`) and the stated designs below.

Compare these two options:
1. A synchronous REST API backed by a relational database that stores the latest payment status.
2. An event-sourced design that stores payment notifications as events and derives the latest status.

Produce an evidence-based comparison for the following areas:
- auditability and recovery
- consistency and duplicate/out-of-order notifications
- operational complexity and availability

For each area, explain the advantage and cost of both designs. Then recommend one design and support the recommendation with trade-offs against the PRD's stated requirements. Explicitly state any assumptions that affect the recommendation.

Finally, identify the two PRD items you would push back on first. For each, give:
- the gap or ambiguity
- why it matters for a bank
- the question you would ask the product owner
- a reasonable default to use until the answer arrives

Keep the response concise: no code, no diagram, and no implementation plan. Do not invent requirements or NFR targets that are absent from the PRD.
